# exercises-2018-winter
Exercises for the Winter 2018 batch of Coding Bootcamp Praha

$('button').on('click', function() {
	$('img').css('opacity', 0.1);
});